Since at this point the assignment hasn't defined a main method or what
the program is supposed to do when run, only the unit tests can be run.
Everything is written in Java 8 with JUnit 5 tests.  I ran these tests
in IntelliJ IDEA, and they all passed.
